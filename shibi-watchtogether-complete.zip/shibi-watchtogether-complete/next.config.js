/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  swcMinify: true,
  images: {
    domains: ['cdn.anilibria.tv', 's4.anilist.co', 'shikimori.one'],
  },
};

module.exports = nextConfig;
