import Link from 'next/link';

export default function Home() {
  return (
    <main className="flex flex-col items-center justify-center min-h-screen gap-8 p-8">
      <h1 className="text-6xl font-bold text-[#D77D31]">SHIBI</h1>
      <p className="text-2xl text-gray-300">Watch Anime Together</p>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-12 w-full max-w-2xl">
        <div className="bg-[#2a2a2a] p-6 rounded-lg hover:bg-[#333] transition">
          <h2 className="text-xl font-bold mb-2">📺 Catalog</h2>
          <p className="text-gray-400 mb-4">Browse thousands of anime</p>
          <Link href="/catalog" className="text-[#D77D31] hover:underline">
            Open Catalog →
          </Link>
        </div>
        
        <div className="bg-[#2a2a2a] p-6 rounded-lg hover:bg-[#333] transition">
          <h2 className="text-xl font-bold mb-2">🤝 Watch Together</h2>
          <p className="text-gray-400 mb-4">Create or join a room</p>
          <Link href="/rooms" className="text-[#D77D31] hover:underline">
            Open Rooms →
          </Link>
        </div>
      </div>

      <div className="mt-12 text-center text-gray-500">
        <p>API Status: <span className="text-green-500">✓ Running</span></p>
        <p className="text-sm mt-2">
          <Link href="/api/health" className="text-[#D77D31] hover:underline">
            Health Check
          </Link>
        </p>
      </div>
    </main>
  );
}
