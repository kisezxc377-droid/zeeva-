'use client';

import React, { useEffect, useRef, useState } from 'react';

interface PlayerProps {
  masterUrl: string;
  roomId?: string;
  onPlay?: () => void;
  onPause?: () => void;
  onSeek?: (time: number) => void;
}

export default function Player({
  masterUrl,
  roomId,
  onPlay,
  onPause,
  onSeek,
}: PlayerProps) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [buffered, setBuffered] = useState(0);

  const togglePlay = () => {
    if (!videoRef.current) return;

    if (videoRef.current.paused) {
      videoRef.current.play();
      setIsPlaying(true);
      onPlay?.();
    } else {
      videoRef.current.pause();
      setIsPlaying(false);
      onPause?.();
    }
  };

  const handleSeek = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!videoRef.current) return;
    const rect = e.currentTarget.getBoundingClientRect();
    const percent = (e.clientX - rect.left) / rect.width;
    const newTime = percent * duration;
    videoRef.current.currentTime = newTime;
    onSeek?.(newTime);
  };

  const formatTime = (seconds: number) => {
    const h = Math.floor(seconds / 3600);
    const m = Math.floor((seconds % 3600) / 60);
    const s = Math.floor(seconds % 60);
    return `${h > 0 ? h + ':' : ''}${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  return (
    <div className="w-full bg-black rounded-lg overflow-hidden">
      <video
        ref={videoRef}
        src={masterUrl}
        className="w-full"
        onPlay={() => setIsPlaying(true)}
        onPause={() => setIsPlaying(false)}
        onTimeUpdate={() => setCurrentTime(videoRef.current?.currentTime || 0)}
        onDurationChange={() => setDuration(videoRef.current?.duration || 0)}
        onProgress={() => {
          const video = videoRef.current;
          if (video && video.buffered.length > 0) {
            const bufferedEnd = video.buffered.end(video.buffered.length - 1);
            setBuffered((bufferedEnd / video.duration) * 100);
          }
        }}
        controls
      />

      <div className="bg-[#2a2a2a] p-4">
        <div className="flex items-center gap-4">
          <button
            onClick={togglePlay}
            className="text-2xl hover:text-[#D77D31] transition"
          >
            {isPlaying ? '⏸' : '▶'}
          </button>

          <div className="flex-1 cursor-pointer" onClick={handleSeek}>
            <div className="bg-gray-700 h-1 rounded relative">
              <div
                className="bg-[#D77D31] h-1 rounded"
                style={{ width: `${(currentTime / duration) * 100 || 0}%` }}
              />
            </div>
          </div>

          <div className="text-sm text-gray-400">
            {formatTime(currentTime)} / {formatTime(duration)}
          </div>
        </div>
      </div>
    </div>
  );
}
