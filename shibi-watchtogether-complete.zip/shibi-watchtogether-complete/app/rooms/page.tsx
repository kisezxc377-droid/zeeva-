'use client';

export default function RoomsPage() {
  const createRoom = () => {
    const id = Math.random().toString(36).substr(2, 9);
    window.location.href = `/room/${id}`;
  };

  return (
    <div className="p-8">
      <h1 className="text-4xl font-bold mb-8">🤝 Watch Together</h1>
      <button
        onClick={createRoom}
        className="bg-[#D77D31] text-white px-8 py-3 rounded font-bold hover:bg-[#c66d21]"
      >
        Create Room
      </button>
    </div>
  );
}
