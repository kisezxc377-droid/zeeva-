'use client';

import { useEffect, useState } from 'react';

interface Anime {
  id: string;
  titleRu: string;
  coverImage?: string;
  status: string;
}

export default function CatalogPage() {
  const [animes, setAnimes] = useState<Anime[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch('http://localhost:3001/api/anime?limit=20')
      .then(r => r.json())
      .then(data => {
        setAnimes(data.data || []);
        setLoading(false);
      })
      .catch(() => setLoading(false));
  }, []);

  if (loading) return <div className="p-8">Loading...</div>;

  return (
    <div className="p-8">
      <h1 className="text-4xl font-bold mb-8">📺 Catalog</h1>
      <div className="grid grid-cols-6 gap-4">
        {animes.map(a => (
          <div key={a.id} className="bg-[#2a2a2a] rounded">
            {a.coverImage && <img src={a.coverImage} alt={a.titleRu} className="w-full h-32"/>}
            <p className="p-2 text-sm truncate">{a.titleRu}</p>
          </div>
        ))}
      </div>
    </div>
  );
}
