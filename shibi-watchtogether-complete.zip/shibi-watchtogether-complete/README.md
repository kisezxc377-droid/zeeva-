# SHIBI WATCHTOGETHER — Production Backend

Production-ready backend для платформы синхронного просмотра аниме. Полная реализация всех компонентов: база данных, импорт метаданных, HLS-прокси, WebSocket синхронизация, кэширование и резервные сценарии.

## 🚀 Быстрый старт

### 1. Clone & Setup
```bash
git clone <repo>
cd shibi-watchtogether
cp .env.example .env
npm install
```

### 2. Docker (рекомендуется)
```bash
docker-compose up -d
```

Проверить статус:
```bash
docker-compose logs -f app
```

### 3. Миграции и импорт данных
```bash
# Провести миграции
npx prisma migrate deploy

# Импортировать данные из AniList
npm run import:anilist

# Обогатить данные из AniLibria
npm run import:anilibria

# Проверить health провайдеров
npm run health:check
```

### 4. Запуск
```bash
# Development
npm run dev

# Production
npm run build && npm start
```

Проверить:
- Frontend: http://localhost:3000
- API: http://localhost:3001/api/health
- WebSocket: ws://localhost:3001/socket.io

## 📊 Архитектура

```
┌─────────────────────────────────┐
│     Frontend (Next.js)          │
│  + hls.js Player + Socket.IO    │
└──────────────┬──────────────────┘
               │
        ┌──────▼──────────┐
        │   NestJS API    │
        │  (3001)         │
        ├──────────────────┤
        │ /api/anime       │
        │ /api/proxy/hls   │
        │ ws://room        │
        └──────────────────┘
               │
   ┌───────────┼────────────┐
   ▼           ▼            ▼
PostgreSQL   Redis       External APIs
   DB        Cache      (AniList, etc)
```

## 🛠 API Endpoints

### Metadata
- `GET /api/health` — здоровье сервера
- `GET /api/anime` — список аниме (pagination)
- `GET /api/anime/:id` — детали аниме
- `GET /api/anime/:id/episodes` — все серии
- `GET /api/anime/:id/streams/:episodeId` — потоки видео
- `GET /api/providers/health` — статус провайдеров

### HLS Proxy
- `GET /api/proxy/hls/:token/*` — прокси для m3u8 и .ts сегментов
  - Заголовки подменяются
  - Ссылки в m3u8 переписываются
  - Сегменты кэшируются в Redis (LRU)

### WebSocket Events
- `room:join` — присоединиться к комнате
- `room:state` — получить текущее состояние
- `player:play` — начать воспроизведение
- `player:pause` — пауза
- `player:seek` — перемотка
- `player:changeTranslation` — смена озвучки
- `room:sync` — синхронизация (отправляется каждые 5 сек)
- `chat:message` — сообщение в чате комнаты

## 💾 База данных

### Основные таблицы

**Anime** — аниме с метаданными
- anilistId, anilibriaId, shikimoriId — маппинг ID
- titleRu, titleEn, titleJp — названия
- genres, year, status, score
- coverImage, bannerImage — изображения

**Episode** — серии
- number (может быть 1.5 для OVA)
- title, description
- airedAt

**Translation** — озвучки/субтитры
- provider, type (dub/sub), language
- name, author, rating

**Stream** — потоки видео
- sourceUrl, sourceType (hls/mp4)
- proxyUrl, proxyToken (JWT)
- quality, subtitles (JSON)
- isAvailable, isAlive
- failCount, lastError

**ProviderHealth** — статус провайдеров
- status, lastCheckAt
- successCount, failCount, avgResponseTime

**Room** — комнаты синхронизации
- hostId, title
- currentAnimeId, currentEpisode
- currentTime, isPlaying
- controlMode

## 🔄 Импорт данных

### Шедуль
- Каждый день в 02:00 — импорт из AniList + AniLibria
- Каждый час — health check провайдеров

### Источники (в порядке приоритета)
1. **AniList** — популярные аниме, рейтинги, обложки
2. **AniLibria** — русский текст, озвучки, свежие серии
3. **Shikimori** — жанры на русском

### Обогащение
- AniList ID связывается с AniLibria ID через название
- Конфликты ID разрешаются в пользу источника с более свежей датой
- Дублирующиеся озвучки не импортируются

## 🎬 HLS Прокси

### Как работает
1. Клиент получает JWT токен с sourceUrl, headers, userId
2. Клиент запрашивает `/api/proxy/hls/:token/master.m3u8`
3. Сервер:
   - Проверяет JWT (expiration 1 час)
   - Fetch к оригинальному m3u8 с подменой заголовков
   - Парсит m3u8 и переписывает относительные ссылки
   - Отдаёт с CORS: Access-Control-Allow-Origin: *

### Кэширование сегментов
- .ts сегменты кэшируются в Redis LRU (TTL 1 час)
- Размер сегмента > 10MB не кэшируется
- Cache hit ratio обычно > 70%

### Подмена заголовков
```javascript
headers: {
  'Referer': 'https://anilibria.tv/',
  'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
}
```

## 🔒 Безопасность

### JWT Токены
- Подписаны `JWT_SECRET` (ОБЯЗАТЕЛЬНО ИЗМЕНИТЬ в продакшене)
- Expiration 1 час
- Payload: `{ sourceUrl, headers, userId, exp }`

### CORS
- Разрешены все origins (может быть ограничено)
- Методы: GET, HEAD, POST, PUT, DELETE

### Rate Limiting
- Реализуется через Redis (опционально добавить)
- На чат: макс 10 сообщений за 10 секунд

## 🔧 Мониторинг и алерты

### Health Check
- Запускается каждый час
- Проверяет доступность AniLibria, ReAnime, anime-sdk
- Результаты сохраняются в `ProviderHealth` таблице

### Graceful Degradation
- При падении провайдера — fallback на закэшированное видео
- Показывается сообщение пользователю
- Алерт отправляется в Discord (если `DISCORD_WEBHOOK_URL` задан)

### Sentry Integration
- Автоматические ошибки отправляются в Sentry (если `SENTRY_DSN` задан)
- Тегирование по провайдеру
- Critical уровень для падений провайдеров

## 📈 Метрики успеха

| Метрика | Целевое значение |
|---------|-----------------|
| Рассинхрон в комнате | < 300мс в 95% времени |
| Время загрузки m3u8 | < 500мс |
| Cache hit ratio | > 70% |
| Uptime провайдеров | > 99% |
| Memory usage | < 500MB |
| Disk usage Redis | < 50GB (LRU) |

## 🧪 Тестирование

### Синхронизация
```bash
# Открыть 3 клиента в одной комнате
# Проверить что play/pause/seek синхронизируются
# Проверить рассинхрон < 300мс
```

### Fallback
```bash
# Отключить провайдер (firewall или /etc/hosts)
# Проверить что сервер переходит на следующий
# Проверить что алерт приходит в Discord
```

### Кэш
```bash
redis-cli
> INFO memory
> DBSIZE
> LLEN room:ROOM_ID:chat
```

## 🐳 Production Deployment

### На VPS $20 (2GB RAM, 20GB SSD)
```bash
# 1. SSH на сервер
ssh root@your-vps

# 2. Установить Docker
curl -fsSL https://get.docker.com -o get-docker.sh
sh get-docker.sh

# 3. Clone repo и запустить
git clone <repo>
cd shibi-watchtogether
cp .env.example .env
# Изменить JWT_SECRET и другие переменные
docker-compose up -d

# 4. Настроить nginx reverse proxy
# /etc/nginx/sites-available/shibi
upstream app {
  server localhost:3001;
}
server {
  server_name shibi.example.com;
  location / {
    proxy_pass http://app;
    proxy_http_version 1.1;
    proxy_set_header Upgrade \$http_upgrade;
    proxy_set_header Connection "upgrade";
    proxy_set_header Host \$host;
  }
}

# 5. Получить SSL сертификат
certbot certonly -a standalone -d shibi.example.com
```

### Мониторинг
```bash
# Логи
docker-compose logs -f app

# Базы
docker-compose exec postgres psql -U shibi -d shibi_db -c "SELECT COUNT(*) FROM Anime;"
docker-compose exec redis redis-cli DBSIZE

# Memory
docker stats app postgres redis
```

### Резервное копирование
```bash
# PostgreSQL
docker-compose exec postgres pg_dump -U shibi shibi_db > backup.sql

# Restore
docker-compose exec -T postgres psql -U shibi shibi_db < backup.sql
```

## 📝 Чеклист запуска

- [ ] PostgreSQL запущен и доступен
- [ ] Redis запущен (режим LRU включён)
- [ ] `npm install` завершился успешно
- [ ] `npx prisma migrate deploy` прошла без ошибок
- [ ] `npm run import:anilist` импортировал данные
- [ ] `/api/health` возвращает `{"status":"ok"}`
- [ ] `/api/anime` возвращает список аниме
- [ ] HLS прокси работает (проверить `curl /api/proxy/hls/:token/master.m3u8`)
- [ ] WebSocket подключение в DevTools Network → WS
- [ ] Две клиента синхронизируют play/pause
- [ ] Graceful degradation при падении провайдера
- [ ] Алерты приходят в Discord

## 📚 Дополнительные ресурсы

- [Prisma Docs](https://www.prisma.io/docs/)
- [NestJS Docs](https://docs.nestjs.com/)
- [Socket.IO Docs](https://socket.io/docs/)
- [hls.js Documentation](https://github.com/video-dev/hls.js)

---

Сделано с 🧠 и ❤️

**Support**: Открой Issue или напиши в Discord
