// Placeholder для seed скрипта
console.log('Seed script placeholder');
