import { Module } from '@nestjs/common';
import { ProxyController } from './controllers/proxy.controller';
import { AnimeController } from './controllers/anime.controller';
import { RoomGateway } from './gateways/room.gateway';
import { ImportService } from './services/import.service';

@Module({
  imports: [],
  controllers: [ProxyController, AnimeController],
  providers: [RoomGateway, ImportService],
})
export class AppModule {}
