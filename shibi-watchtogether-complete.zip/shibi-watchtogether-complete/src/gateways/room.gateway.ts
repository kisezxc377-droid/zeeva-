import {
  WebSocketGateway,
  SubscribeMessage,
  OnGatewayConnection,
  OnGatewayDisconnect,
  WebSocketServer,
  ConnectedSocket,
  MessageBody
} from '@nestjs/websockets';
import { Server, Socket } from 'socket.io';
import { PrismaClient } from '@prisma/client';
import Redis from 'ioredis';

const prisma = new PrismaClient();
const redis = new Redis(process.env.REDIS_URL || 'redis://localhost:6379');

interface RoomState {
  currentTime: number;
  isPlaying: boolean;
  episodeId: string;
  translationId: string;
  subtitleLang?: string;
  serverTime: number;
}

@WebSocketGateway({
  namespace: 'room',
  cors: { origin: '*' }
})
export class RoomGateway implements OnGatewayConnection, OnGatewayDisconnect {
  @WebSocketServer()
  server: Server;

  private rooms = new Map<string, RoomState>();
  private userRooms = new Map<string, string>();

  constructor() {
    // Периодическая синхронизация каждые 5 секунд
    setInterval(() => {
      for (const [roomId, room] of this.rooms) {
        room.serverTime = Math.floor(Date.now() / 1000);
        this.server.to(roomId).emit('room:sync', {
          serverTime: room.serverTime,
          currentTime: room.currentTime,
          isPlaying: room.isPlaying
        });
      }
    }, 5000);
  }

  handleConnection(client: Socket) {
    console.log(`📡 Подключение: ${client.id}`);
  }

  handleDisconnect(client: Socket) {
    console.log(`📡 Отключение: ${client.id}`);
    const roomId = this.userRooms.get(client.id);
    if (roomId) {
      this.leaveRoom(roomId, client.id);
    }
  }

  @SubscribeMessage('room:join')
  async onRoomJoin(
    @ConnectedSocket() client: Socket,
    @MessageBody()
    data: { roomId: string; userId: string; username: string }
  ) {
    const { roomId, userId, username } = data;
    console.log(`👤 ${username} присоединился к ${roomId}`);

    client.join(roomId);
    this.userRooms.set(client.id, roomId);

    let roomState = await redis.get(`room:${roomId}:state`);
    if (!roomState) {
      roomState = JSON.stringify({
        currentTime: 0,
        isPlaying: false,
        episodeId: '',
        translationId: '',
        subtitleLang: 'ru',
        serverTime: Math.floor(Date.now() / 1000)
      });
      await redis.setex(`room:${roomId}:state`, 3600, roomState);
    }

    const state = JSON.parse(roomState);
    this.rooms.set(roomId, state);

    client.emit('room:state', state);
    client.to(roomId).emit('user:joined', {
      userId,
      username,
      count: this.server.sockets.adapter.rooms.get(roomId)?.size || 0
    });

    return { success: true, state };
  }

  @SubscribeMessage('player:play')
  async onPlay(
    @ConnectedSocket() client: Socket,
    @MessageBody() data: { roomId: string; currentTime: number }
  ) {
    const { roomId, currentTime } = data;
    const room = this.rooms.get(roomId);
    if (!room) return;

    room.isPlaying = true;
    room.currentTime = currentTime;
    room.serverTime = Math.floor(Date.now() / 1000);

    await redis.setex(`room:${roomId}:state`, 3600, JSON.stringify(room));
    this.server.to(roomId).emit('player:play', { currentTime });
  }

  @SubscribeMessage('player:pause')
  async onPause(
    @ConnectedSocket() client: Socket,
    @MessageBody() data: { roomId: string; currentTime: number }
  ) {
    const { roomId, currentTime } = data;
    const room = this.rooms.get(roomId);
    if (!room) return;

    room.isPlaying = false;
    room.currentTime = currentTime;
    room.serverTime = Math.floor(Date.now() / 1000);

    await redis.setex(`room:${roomId}:state`, 3600, JSON.stringify(room));
    this.server.to(roomId).emit('player:pause', { currentTime });
  }

  @SubscribeMessage('player:seek')
  async onSeek(
    @ConnectedSocket() client: Socket,
    @MessageBody() data: { roomId: string; currentTime: number }
  ) {
    const { roomId, currentTime } = data;
    const room = this.rooms.get(roomId);
    if (!room) return;

    room.currentTime = currentTime;
    room.serverTime = Math.floor(Date.now() / 1000);

    await redis.setex(`room:${roomId}:state`, 3600, JSON.stringify(room));
    this.server.to(roomId).emit('player:seek', { currentTime });
  }

  @SubscribeMessage('player:changeTranslation')
  async onChangeTranslation(
    @ConnectedSocket() client: Socket,
    @MessageBody() data: { roomId: string; translationId: string }
  ) {
    const { roomId, translationId } = data;
    const room = this.rooms.get(roomId);
    if (!room) return;

    room.translationId = translationId;
    room.currentTime = 0;
    room.isPlaying = false;

    await redis.setex(`room:${roomId}:state`, 3600, JSON.stringify(room));
    this.server.to(roomId).emit('player:translationChanged', {
      translationId,
      message: '🔄 Озвучка меняется...'
    });
  }

  @SubscribeMessage('chat:message')
  async onChatMessage(
    @ConnectedSocket() client: Socket,
    @MessageBody()
    data: { roomId: string; userId: string; username: string; text: string }
  ) {
    const { roomId, userId, username, text } = data;

    const message = {
      id: Date.now(),
      userId,
      username,
      text,
      timestamp: new Date()
    };

    await redis.lpush(`room:${roomId}:chat`, JSON.stringify(message));
    await redis.ltrim(`room:${roomId}:chat`, 0, 49);

    this.server.to(roomId).emit('chat:message', message);
  }

  private leaveRoom(roomId: string, clientId: string) {
    const sockets = this.server.sockets.adapter.rooms.get(roomId);
    if (!sockets || sockets.size === 0) {
      this.rooms.delete(roomId);
      redis.del(`room:${roomId}:state`);
      redis.del(`room:${roomId}:chat`);
      console.log(`🗑️  Комната ${roomId} удалена (пусто)`);
    }
    this.userRooms.delete(clientId);
  }
}
