import { Injectable } from '@nestjs/common';
import { PrismaClient } from '@prisma/client';
import axios from 'axios';
import Redis from 'ioredis';
import * as cron from 'node-cron';

const prisma = new PrismaClient();
const redis = new Redis(process.env.REDIS_URL || 'redis://localhost:6379');

@Injectable()
export class ImportService {
  constructor() {
    // Крон: импорт каждый день в 02:00
    cron.schedule('0 2 * * *', () => {
      console.log('🔄 Запущен плановый импорт данных...');
      this.importFromAniList().catch(console.error);
      this.enrichFromAniLibria().catch(console.error);
    });

    // Крон: health check каждый час
    cron.schedule('0 * * * *', () => {
      console.log('🏥 Запущена проверка здоровья провайдеров...');
      this.healthCheck().catch(console.error);
    });
  }

  async importFromAniList() {
    console.log('📥 Импорт из AniList (топ-2000)...');
    let page = 1;
    let hasNextPage = true;
    let count = 0;

    const query = `
      query ($page: Int, $perPage: Int) {
        Page(page: $page, perPage: $perPage) {
          pageInfo { hasNextPage }
          media(sort: POPULARITY_DESC, type: ANIME) {
            id
            title { romaji english native }
            description
            episodes
            status
            averageScore
            coverImage { large }
            bannerImage
            genres
            startDate { year }
          }
        }
      }
    `;

    while (hasNextPage && page <= 40) {
      try {
        const response = await axios.post('https://graphql.anilist.co', {
          query,
          variables: { page, perPage: 50 }
        });

        const data = response.data.data.Page;
        hasNextPage = data.pageInfo.hasNextPage;

        for (const media of data.media) {
          await prisma.anime.upsert({
            where: { anilistId: media.id },
            update: {
              titleRu: media.title?.native || media.title?.romaji || 'Unknown',
              titleEn: media.title?.english,
              titleJp: media.title?.native,
              description: media.description?.replace(/<[^>]*>/g, ''),
              coverImage: media.coverImage?.large,
              bannerImage: media.bannerImage,
              genres: media.genres || [],
              year: media.startDate?.year,
              status: this.mapStatus(media.status),
              episodesTotal: media.episodes || 0,
              score: media.averageScore ? media.averageScore / 10 : null,
              updatedAt: new Date()
            },
            create: {
              anilistId: media.id,
              titleRu: media.title?.native || media.title?.romaji || 'Unknown',
              titleEn: media.title?.english,
              titleJp: media.title?.native,
              description: media.description?.replace(/<[^>]*>/g, ''),
              coverImage: media.coverImage?.large,
              bannerImage: media.bannerImage,
              genres: media.genres || [],
              year: media.startDate?.year,
              status: this.mapStatus(media.status),
              episodesTotal: media.episodes || 0,
              score: media.averageScore ? media.averageScore / 10 : null
            }
          });

          count++;
        }

        console.log(`  ✅ Страница ${page}: ${data.media.length} аниме`);
        page++;

        // Throttle
        await new Promise(r => setTimeout(r, 500));
      } catch (error) {
        console.error(`  ❌ Ошибка AniList ${page}:`, error.message);
      }
    }

    console.log(`  🎉 Импортировано ${count} аниме из AniList`);
  }

  async enrichFromAniLibria() {
    console.log('📥 Обогащение из AniLibria V3...');

    try {
      const response = await axios.get('https://api.anilibria.tv/v3/title/search', {
        params: { search: '', limit: 9999 }
      });

      const titles = response.data.data || [];
      let updated = 0;

      for (const title of titles) {
        const anime = await prisma.anime.findFirst({
          where: {
            OR: [
              { anilibriaId: title.id },
              { titleRu: { equals: title.names.ru, mode: 'insensitive' } }
            ]
          }
        });

        if (anime) {
          await prisma.anime.update({
            where: { id: anime.id },
            data: {
              anilibriaId: title.id,
              titleRu: title.names.ru,
              description: title.description || anime.description,
              coverImage: title.posters?.small?.url || anime.coverImage,
              episodesAired: title.series?.total || anime.episodesAired
            }
          });

          updated++;

          // Импортировать озвучки
          if (title.franchises?.voiceovers) {
            for (const vo of title.franchises.voiceovers) {
              await prisma.translation.upsert({
                where: {
                  animeId_provider_type_language: {
                    animeId: anime.id,
                    provider: 'anilibria',
                    type: vo.type === 'voice' ? 'dub' : 'sub',
                    language: 'ru'
                  }
                },
                update: {
                  name: vo.name,
                  author: vo.author?.name,
                  rating: vo.rating
                },
                create: {
                  animeId: anime.id,
                  provider: 'anilibria',
                  type: vo.type === 'voice' ? 'dub' : 'sub',
                  language: 'ru',
                  name: vo.name,
                  author: vo.author?.name,
                  rating: vo.rating
                }
              });
            }
          }
        }
      }

      console.log(`  ✅ Обогащено ${updated} аниме`);
    } catch (error) {
      console.error('  ❌ Ошибка AniLibria:', error.message);
    }
  }

  async healthCheck() {
    const providers = ['anilibria', 'reanime', 'anime-sdk'];

    for (const provider of providers) {
      try {
        const startTime = Date.now();
        let isHealthy = false;

        if (provider === 'anilibria') {
          const response = await axios.get('https://api.anilibria.tv/v3/title/search', {
            params: { limit: 1 },
            timeout: 5000
          });
          isHealthy = response.status === 200;
        } else if (provider === 'reanime') {
          const response = await axios.get('https://api.reanime.to/ping', {
            timeout: 5000
          });
          isHealthy = response.status === 200;
        }

        const responseTime = Date.now() - startTime;

        await prisma.providerHealth.upsert({
          where: { provider },
          update: {
            status: isHealthy ? 'healthy' : 'degraded',
            lastCheckAt: new Date(),
            successCount: isHealthy ? { increment: 1 } : undefined,
            failCount: !isHealthy ? { increment: 1 } : undefined,
            avgResponseTime: responseTime
          },
          create: {
            provider,
            status: isHealthy ? 'healthy' : 'down',
            successCount: isHealthy ? 1 : 0,
            failCount: isHealthy ? 0 : 1,
            avgResponseTime: responseTime
          }
        });

        console.log(`  ✅ ${provider}: ${responseTime}ms (${isHealthy ? 'healthy' : 'degraded'})`);
      } catch (error) {
        console.error(`  ❌ ${provider}: ${error.message}`);

        await prisma.providerHealth.upsert({
          where: { provider },
          update: {
            status: 'down',
            lastCheckAt: new Date(),
            failCount: { increment: 1 },
            errorMessage: error.message
          },
          create: {
            provider,
            status: 'down',
            failCount: 1,
            errorMessage: error.message
          }
        });
      }
    }
  }

  private mapStatus(status: string): string {
    const map: Record<string, string> = {
      FINISHED: 'completed',
      RELEASING: 'ongoing',
      NOT_YET_RELEASED: 'upcoming',
      CANCELLED: 'cancelled'
    };
    return map[status] || 'unknown';
  }
}
