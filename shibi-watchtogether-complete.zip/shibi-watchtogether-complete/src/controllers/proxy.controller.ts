import {
  Controller,
  Get,
  Param,
  Res,
  HttpException,
  HttpStatus,
  Req,
  All
} from '@nestjs/common';
import { Response, Request } from 'express';
import axios from 'axios';
import jwt from 'jsonwebtoken';
import Redis from 'ioredis';
import crypto from 'crypto';

const redis = new Redis(process.env.REDIS_URL || 'redis://localhost:6379');

interface ProxyToken {
  sourceUrl: string;
  headers: Record<string, string>;
  userId: string;
  exp: number;
}

@Controller('api/proxy')
export class ProxyController {
  generateProxyToken(sourceUrl: string, userId: string): string {
    const payload: ProxyToken = {
      sourceUrl,
      headers: {
        'Referer': 'https://anilibria.tv/',
        'User-Agent':
          'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
      },
      userId,
      exp: Math.floor(Date.now() / 1000) + 3600
    };

    return jwt.sign(payload, process.env.JWT_SECRET || 'secret');
  }

  @All('hls/:token/*')
  async proxyHls(
    @Param('token') token: string,
    @Res() res: Response,
    @Req() req: Request
  ) {
    try {
      const payload = jwt.verify(
        token,
        process.env.JWT_SECRET || 'secret'
      ) as ProxyToken;

      if (payload.exp < Math.floor(Date.now() / 1000)) {
        throw new HttpException('Token expired', HttpStatus.UNAUTHORIZED);
      }

      const sourceUrl = payload.sourceUrl;
      const path = req.url.split(`/hls/${token}/`)[1];

      console.log(`📡 Прокси запрос: ${sourceUrl} + /${path}`);

      const response = await axios.get(`${sourceUrl}/${path}`, {
        headers: {
          ...payload.headers,
          Range: (req.headers.range as string) || undefined
        },
        timeout: 10000,
        responseType: path.endsWith('.m3u8') ? 'text' : 'stream'
      });

      // Обработать m3u8
      if (path.endsWith('.m3u8')) {
        let manifest = response.data;
        const lines = manifest.split('\n');

        const processedLines = lines.map(line => {
          if (line.trim() && !line.startsWith('#') && !line.startsWith('http')) {
            return `/api/proxy/hls/${token}/${line}`;
          }
          return line;
        });

        manifest = processedLines.join('\n');

        res.setHeader('Content-Type', 'application/vnd.apple.mpegurl');
        res.setHeader('Cache-Control', 'public, max-age=3600');
        res.setHeader('Access-Control-Allow-Origin', '*');
        res.send(manifest);
        return;
      }

      // Кэшировать .ts сегменты
      const cacheKey = `hls:segment:${crypto
        .createHash('sha256')
        .update(`${sourceUrl}/${path}`)
        .digest('hex')}`;

      const cached = await redis.getBuffer(cacheKey);
      if (cached) {
        console.log(`✅ Cache HIT: ${path}`);
        res.setHeader('Content-Type', 'video/mp2t');
        res.setHeader('X-Cache', 'HIT');
        res.setHeader('Access-Control-Allow-Origin', '*');
        res.send(cached);
        return;
      }

      const contentLength = parseInt(response.headers['content-length'] || '0');
      if (contentLength > 10 * 1024 * 1024) {
        res.setHeader('Content-Type', 'video/mp2t');
        res.setHeader('X-Cache', 'MISS');
        res.setHeader('Access-Control-Allow-Origin', '*');
        response.data.pipe(res);
        return;
      }

      const buffer = await this.streamToBuffer(response.data);
      await redis.setex(cacheKey, 3600, buffer);

      res.setHeader('Content-Type', 'video/mp2t');
      res.setHeader('X-Cache', 'MISS');
      res.setHeader('Access-Control-Allow-Origin', '*');
      res.send(buffer);
    } catch (error) {
      console.error('❌ Proxy error:', error.message);
      res.status(HttpStatus.BAD_GATEWAY).json({
        error: 'Proxy error',
        message: error.message
      });
    }
  }

  private streamToBuffer(stream: any): Promise<Buffer> {
    return new Promise((resolve, reject) => {
      const chunks: Buffer[] = [];
      stream.on('data', chunk => chunks.push(chunk));
      stream.on('error', reject);
      stream.on('end', () => resolve(Buffer.concat(chunks)));
    });
  }
}
