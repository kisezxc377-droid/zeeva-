import { Controller, Get, Param, Query } from '@nestjs/common';
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

@Controller('api')
export class AnimeController {
  @Get('health')
  async health() {
    return { status: 'ok', timestamp: new Date() };
  }

  @Get('anime')
  async getAnime(@Query('limit') limit = '20', @Query('page') page = '1') {
    const l = Math.min(parseInt(limit), 100);
    const p = Math.max(parseInt(page), 1);

    const animes = await prisma.anime.findMany({
      take: l,
      skip: (p - 1) * l,
      orderBy: { updatedAt: 'desc' },
      include: {
        episodes: { take: 3, orderBy: { number: 'asc' } }
      }
    });

    const total = await prisma.anime.count();

    return {
      data: animes,
      pagination: {
        total,
        page: p,
        limit: l,
        pages: Math.ceil(total / l)
      }
    };
  }

  @Get('anime/:id')
  async getAnimeById(@Param('id') id: string) {
    const anime = await prisma.anime.findUnique({
      where: { id },
      include: {
        episodes: { orderBy: { number: 'asc' } },
        translations: true,
        streams: { take: 10 }
      }
    });

    if (!anime) {
      return { error: 'Anime not found' };
    }

    return anime;
  }

  @Get('anime/:id/episodes')
  async getEpisodes(@Param('id') id: string) {
    const episodes = await prisma.episode.findMany({
      where: { animeId: id },
      orderBy: { number: 'asc' },
      include: {
        streams: {
          where: { isAvailable: true },
          include: { translation: true }
        }
      }
    });

    return episodes;
  }

  @Get('anime/:id/streams/:episodeId')
  async getStreams(
    @Param('id') id: string,
    @Param('episodeId') episodeId: string
  ) {
    const streams = await prisma.stream.findMany({
      where: {
        animeId: id,
        episodeId,
        isAvailable: true,
        isAlive: true
      },
      include: { translation: true }
    });

    return { streams, count: streams.length };
  }

  @Get('providers/health')
  async getProviderHealth() {
    const health = await prisma.providerHealth.findMany({
      orderBy: { lastCheckAt: 'desc' }
    });

    return { providers: health };
  }
}
