import { NestFactory } from '@nestjs/core';
import { AppModule } from './app.module';
import * as Sentry from '@sentry/node';
import helmet from 'helmet';
import compression from 'compression';

async function bootstrap() {
  if (process.env.SENTRY_DSN) {
    Sentry.init({
      dsn: process.env.SENTRY_DSN,
      environment: process.env.NODE_ENV || 'development',
      tracesSampleRate: 0.1
    });
  }

  const app = await NestFactory.create(AppModule);

  app.use(helmet());
  app.use(compression());
  app.enableCors({
    origin: '*',
    allowedHeaders: ['Content-Type', 'Authorization'],
    methods: ['GET', 'HEAD', 'POST', 'PUT', 'DELETE']
  });

  const port = process.env.PORT || 3001;
  await app.listen(port);

  console.log(`🚀 SHIBI API запущен на порту ${port}`);
  console.log(`📡 WebSocket слушает на ws://localhost:${port}/socket.io`);
}

bootstrap().catch(err => {
  console.error('❌ Ошибка запуска:', err);
  process.exit(1);
});
